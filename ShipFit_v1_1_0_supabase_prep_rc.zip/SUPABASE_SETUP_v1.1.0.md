# ShipFit v1.1.0 Supabase Prep Setup

Status: PREPARED, NOT CONNECTED, NOT BROWSER VERIFIED.

## Scope

ShipFit remains a standalone HTML/CSS/JS PWA with localStorage as the primary persistence layer.
Supabase is prepared only for optional cloud backup/sync of the active local profile.

Do not connect this to CropMarine production. Create a separate Supabase project for ShipFit.

## What the app syncs

Table: `public.shipfit_user_history`

One row per authenticated Supabase user and ShipFit profile:

- `profile_id = 'daniil'`
- `profile_id = 'second'`

The app stores a JSON backup payload created by `collectBackupData()`.

## Apply SQL

Open the ShipFit Supabase project SQL editor and run:

```sql
-- use the file in this package:
-- supabase_schema.sql
```

Then run the verification queries at the bottom of `supabase_schema.sql`.

## Auth setup

In Supabase Dashboard:

1. Authentication -> Providers -> Email.
2. Enable Email provider.
3. For the first pilot, keep signups controlled.
4. Add Daniil and Second as users manually, or temporarily allow invite/sign-up during setup.
5. Add the deployed app URL to allowed redirect URLs.

Example redirect URL:

```text
https://your-shipfit-host.netlify.app/
```

or Cloudflare/Workers URL:

```text
https://shipfit.example.workers.dev/
```

## App setup

In ShipFit:

1. Open Daniil or Second local profile first.
2. Go to Settings -> Supabase cloud config.
3. Enter Supabase URL.
4. Enter anon public key.
5. Enter email.
6. Click Save Supabase config.
7. Click Send Magic Link.
8. Open the email link on the same device/browser.
9. Click Sync active profile.

## Data safety rule

Before first Pull from Supabase, export local JSON backup.
Pull from Supabase replaces local data for the active profile.

## Acceptance checks

- Daniil profile keeps Russian by default.
- Second profile keeps English by default.
- Supabase sign-in does not replace `shipfitProfile` with the Auth UUID.
- `profile_id` in Supabase is `daniil` or `second`, not a random UUID.
- Sync writes only the authenticated user own row.
- Pull reads only the authenticated user own row.
- Local PWA still works if Supabase CDN or network is unavailable.
