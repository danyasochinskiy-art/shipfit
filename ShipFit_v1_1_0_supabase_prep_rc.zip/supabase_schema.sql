-- ShipFit v1.1.0 Supabase Prep
-- Apply only in a separate ShipFit Supabase project.
-- Do NOT apply this SQL in CropMarine production.
-- Storage is not required for v1.1.0. Sync stores one JSON backup per authenticated user/profile.

begin;

create extension if not exists pgcrypto;

create table if not exists public.shipfit_user_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  profile_id text not null check (profile_id in ('daniil', 'second')),
  app_version text not null default 'unknown',
  device_id text,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  constraint shipfit_user_history_user_profile_key unique(user_id, profile_id)
);

comment on table public.shipfit_user_history is
  'ShipFit private per-user profile backup table. One row per Supabase user and local profile.';
comment on column public.shipfit_user_history.profile_id is
  'Allowed local profiles: daniil, second. This keeps the two-user local model stable in cloud sync.';
comment on column public.shipfit_user_history.data is
  'JSON payload created by ShipFit collectBackupData(). Contains only the authenticated user own app data.';

create or replace function public.shipfit_set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_shipfit_user_history_updated_at on public.shipfit_user_history;
create trigger trg_shipfit_user_history_updated_at
before update on public.shipfit_user_history
for each row
execute function public.shipfit_set_updated_at();

alter table public.shipfit_user_history enable row level security;

revoke all on table public.shipfit_user_history from anon;
revoke all on table public.shipfit_user_history from authenticated;
grant select, insert, update, delete on table public.shipfit_user_history to authenticated;

-- Read only own cloud backups.
drop policy if exists shipfit_select_own on public.shipfit_user_history;
create policy shipfit_select_own
on public.shipfit_user_history
for select
to authenticated
using (auth.uid() = user_id);

-- Insert only rows owned by the current authenticated user.
drop policy if exists shipfit_insert_own on public.shipfit_user_history;
create policy shipfit_insert_own
on public.shipfit_user_history
for insert
to authenticated
with check (auth.uid() = user_id);

-- Update only own rows and prevent moving a row to another owner.
drop policy if exists shipfit_update_own on public.shipfit_user_history;
create policy shipfit_update_own
on public.shipfit_user_history
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- User may delete only own cloud backup row. The app does not call delete in v1.1.0.
drop policy if exists shipfit_delete_own on public.shipfit_user_history;
create policy shipfit_delete_own
on public.shipfit_user_history
for delete
to authenticated
using (auth.uid() = user_id);

create index if not exists idx_shipfit_user_history_user_id
on public.shipfit_user_history(user_id);

create index if not exists idx_shipfit_user_history_updated_at
on public.shipfit_user_history(updated_at desc);

commit;

-- Verification queries after applying:
-- 1) RLS enabled:
-- select schemaname, tablename, rowsecurity from pg_tables where schemaname='public' and tablename='shipfit_user_history';
-- 2) Policies:
-- select policyname, cmd, roles, qual, with_check from pg_policies where schemaname='public' and tablename='shipfit_user_history' order by policyname;
-- 3) Grants:
-- select grantee, privilege_type from information_schema.role_table_grants where table_schema='public' and table_name='shipfit_user_history' order by grantee, privilege_type;
