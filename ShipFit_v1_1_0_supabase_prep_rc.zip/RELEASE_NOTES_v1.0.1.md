# Release Notes: ShipFit v1.0.1 Verification Hardened RC

## Summary

v1.0.1 corrects the premature "final release" status and turns the package into a better verified release candidate.

## Added

- Verification Status panel in Plan tab.
- `window.SHIPFIT_VERSION`.
- Node runtime smoke test script.
- Node runtime smoke output.
- Verification report.

## Fixed

- `getWeekPattern()` now uses safe modulo logic for dates before the app START date.
- Version/status wording changed from final release to release candidate.

## Verification

- Static audit: PASS.
- Node runtime smoke: PASS.
- Headless Chromium smoke: BLOCKED by environment.
- Mobile smoke: NOT TESTED.

## Release decision

Ready for test deploy: YES  
Final verified release: NO  
Supabase/cloud release: NO
