# ShipFit v0.5.2 Setup: Supabase Magic Link + free Cloudflare Pages domain

## What this version does

- Email-only Magic Link login.
- No password field in the app.
- Session stays saved in browser after the email link is opened.
- Data syncs to Supabase table `shipfit_user_history`.
- Local fallback is still available for testing.
- Recommended free hosting: Cloudflare Pages `*.pages.dev`.

## 1. Create a separate Supabase project

Do not use CropMarine Portal production Supabase.

1. Go to Supabase Dashboard.
2. Create a new project, for example `shipfit`.
3. Open SQL Editor.
4. Run `supabase_schema.sql` from this ZIP.

## 2. Create users

Recommended private mode:

1. Authentication → Users.
2. Create Daniil's user by email.
3. Create second user by email.
4. Keep app code with `shouldCreateUser: false`, so unknown emails cannot auto-register.

## 3. Deploy on free Cloudflare Pages domain

1. Open Cloudflare Dashboard.
2. Workers & Pages → Create application.
3. Choose Pages → Direct Upload.
4. Upload the contents of this folder or the ZIP.
5. Project will be available as:
   `https://PROJECT_NAME.pages.dev`

Example:
`https://shipfit.pages.dev`

## 4. Configure Supabase Auth URLs

Supabase Dashboard → Authentication → URL Configuration:

- Site URL:
  `https://PROJECT_NAME.pages.dev`

- Redirect URLs:
  `https://PROJECT_NAME.pages.dev`
  `https://PROJECT_NAME.pages.dev/*`

Magic Link will redirect users back to this URL.

## 5. Configure app

Open ShipFit login screen:

1. Paste Supabase URL.
2. Paste Supabase anon public key.
3. Press `Save config`.
4. Enter email.
5. Press `Send login link`.
6. Open email link on the same device/browser.

## 6. Test

Expected:
- After clicking email link, ShipFit opens logged in.
- Close browser tab.
- Open ShipFit again.
- It should stay logged in.
- Press `Sync to Supabase`, then `Pull from Supabase`.

## Notes

- Magic Link will not work correctly from `file:///.../index.html`.
- Use a real HTTPS URL, for example Cloudflare Pages `pages.dev`.
- If you use local fallback, data remains in localStorage only.
- GIF media still loads from GitHub educational dataset.
