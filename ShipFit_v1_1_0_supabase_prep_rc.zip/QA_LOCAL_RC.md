# ShipFit v0.6.1 Local QA Checklist

Status values:
- PASS
- FAIL
- BLOCKED
- NOT TESTED

## 1. Start / login

- [ ] Open `index.html`.
- [ ] Click `Daniil local`.
- [ ] App opens without blank screen.
- [ ] Profile chip shows Daniil.

Status: NOT TESTED

## 2. Today screen

- [ ] Today training card is visible.
- [ ] Backup reminder is visible.
- [ ] Week strip is visible.
- [ ] Last workout summary empty state is readable.

Status: NOT TESTED

## 3. Workout Focus Mode Pro

- [ ] Press Start workout.
- [ ] Focus panel shows one exercise.
- [ ] Enter weight and reps.
- [ ] Press Done set.
- [ ] Rest timer starts.
- [ ] Next set appears.
- [ ] Skip exercise works.
- [ ] Finish workout creates summary.

Status: NOT TESTED

## 4. Progress

- [ ] Exercise progress dashboard updates after saved sets.
- [ ] Backup Export JSON works.
- [ ] Import JSON works after reload.
- [ ] Diagnostics JSON export works.

Status: NOT TESTED

## 5. Calendar

- [ ] Month calendar renders.
- [ ] Auto-reschedule missed workouts works.
- [ ] Move today to next free day works.
- [ ] Port days are visually different.

Status: NOT TESTED

## 6. Recovery / Nutrition

- [ ] Save Recovery works.
- [ ] Apply Recovery advice works.
- [ ] Save Nutrition works.
- [ ] Nutrition weekly consistency updates.

Status: NOT TESTED

## 7. PWA shell

- [ ] On local file mode, PWA panel says http/https required.
- [ ] On local server or hosting, Enable offline shell works.
- [ ] App cache can be cleared.
- [ ] Offline status appears when browser goes offline.

Status: NOT TESTED

## 8. Known limitations

- Supabase Magic Link is prepared but not deployed.
- Cloudflare Pages is deferred.
- GIFs are still remote GitHub assets.
- Browser/mobile smoke test must be done manually.


## 9. Plan tab

- [ ] Open Plan tab.
- [ ] Roadmap is visible.
- [ ] Release gate statuses can be changed.
- [ ] Next build queue is visible.
- [ ] Switching away and back keeps release gate statuses.

Status: NOT TESTED


## 10. Manual QA panel

- [ ] Open Plan tab.
- [ ] Press Start QA session.
- [ ] Change one item to PASS.
- [ ] Add note.
- [ ] Switch tab and return.
- [ ] Status and note remain saved.
- [ ] Export QA report.

Status: NOT TESTED


## 11. Workout Engine Pro

- [ ] Start workout.
- [ ] Workout progress hero is visible.
- [ ] Focus panel shows one exercise and one set.
- [ ] Weight +/- buttons work.
- [ ] Reps +/- buttons work.
- [ ] Done set saves set.
- [ ] Rest timer starts and can be stopped.
- [ ] Next set appears after Done set.
- [ ] Skip exercise asks confirmation.
- [ ] Completion state appears after all exercises are done/skipped.
- [ ] Finish workout creates summary with total sets and volume.
- [ ] Collapsible all-exercises view still opens.

Status: NOT TESTED


## 11. v0.9.0 Progress Intelligence

- [ ] Recovery card appears only on Today tab.
- [ ] Nutrition tracker appears only on Today tab.
- [ ] Local QA App version check passes.
- [ ] Language toggle changes visible dynamic labels.
- [ ] Open Progress tab.
- [ ] Next workout intelligence card is visible.
- [ ] Weekly progress review card is visible.
- [ ] Progress insights card is visible.
- [ ] Complete at least one workout and check that weekly review updates.

Status: NOT TESTED


## 12. v1.0.0 Final Local Release

- [ ] Open test deployed URL.
- [ ] Login via Daniil local.
- [ ] Run local QA diagnostics.
- [ ] Recovery/Nutrition visible only on Today.
- [ ] Start and finish one workout.
- [ ] Progress Intelligence updates.
- [ ] Export backup.
- [ ] Export QA report.
- [ ] Test on phone.

Status: NOT TESTED
