# Final Release Notes: ShipFit v1.0.0 Final Local Release

## Release type

Final local release for test deploy and daily local use.

This is not a Supabase/cloud production release.

## What is included

- Local login profiles:
  - Daniil local
  - Second local
- Ship voyage calendar.
- Workout Engine Pro.
- Progress Intelligence.
- Recovery tracker.
- Nutrition tracker.
- Backup / restore.
- Manual QA panel.
- Diagnostics export.
- PWA manifest.
- Offline app shell for http/https.

## What is intentionally deferred

- Supabase Magic Link setup.
- Cloud sync.
- Cloudflare production hardening.
- Paid/public distribution.
- Local GIF media replacement.

## Critical fixes inherited from v0.9.0

- Recovery/Nutrition section boundary fixed.
- localHealthChecks version check fixed for v1.0.
- setupLanguage called during boot.
- Progress Intelligence cards added.

## Verification

- node --check js/app.js: PASS
- duplicate HTML IDs: PASS
- inline handler target functions: PASS
- duplicate function declarations: PASS
- Today section contains Recovery + Nutrition: PASS
- Calendar section does not contain Recovery + Nutrition: PASS
- old hardcoded APP_VERSION checks: PASS
- setupLanguage called during boot: PASS

## Not verified here

- Real browser click-through.
- Mobile Safari.
- Android Chrome.
- PWA installed mode.
- Cloudflare Pages test deploy.

## Acceptance

This build is ready for test deployment.
After test deployment, complete `DEPLOY_TEST_CHECKLIST.md`.

## Rollback

Use v0.9.0 only if v1.0.0 introduces a new blocking bug.
