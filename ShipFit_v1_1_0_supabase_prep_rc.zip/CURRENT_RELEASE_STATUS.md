# ShipFit Current Release Status

## Current version

Version: v1.0.1 Verification Hardened RC

## Status

- Prepared: YES
- Ready for test deploy: YES
- Final verified release: NO
- Uploaded to hosting: NO
- Supabase configured: NO
- Mobile smoke tested: NO
- Local QA completed by user: NO

## Changed files

- index.html
- css/styles.css
- js/app.js
- README.txt
- CURRENT_RELEASE_STATUS.md
- VERIFICATION_REPORT_v1.0.1.md
- RELEASE_NOTES_v1.0.1.md
- STATIC_AUDIT_v1.0.1.md
- NODE_RUNTIME_SMOKE_v1.0.1.js
- NODE_RUNTIME_SMOKE_v1.0.1_output.json

## Fixes since v1.0.0

- Changed status from "final" to "release candidate".
- Added verification panel in Plan tab.
- Added `window.SHIPFIT_VERSION`.
- Added safe sequence logic in `getWeekPattern()` for dates before START.
- Added Node runtime smoke test output.

## Verification

- node --check js/app.js: PASS
- duplicate HTML IDs: PASS
- inline handler target functions: PASS
- duplicate function declarations: PASS
- static DOM ID references: PASS
- nav tabs match sections: PASS
- Today contains Recovery + Nutrition: PASS
- Calendar does not contain Recovery + Nutrition: PASS
- setupLanguage called during boot: PASS
- boot order: PASS
- safe workout sequence before START: PASS
- Node runtime smoke: PASS
- Chromium browser smoke: BLOCKED by container environment
- mobile smoke: NOT TESTED

## Current Next Action

Upload this RC to test hosting and complete DEPLOY_TEST_CHECKLIST.md.
If bugs are found: v1.0.2 bugfix.
