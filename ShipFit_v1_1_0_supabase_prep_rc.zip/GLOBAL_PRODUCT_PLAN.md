# ShipFit Global Product Plan

## Product goal

Build a practical ship gym fitness app for Daniil that works first as a stable local app, then later as a private cloud/PWA product.

## Strategy

1. Finish local app stability.
2. Make workout flow truly usable during training.
3. Add useful progress intelligence.
4. Improve calendar and recovery decisions.
5. Only then enable Supabase, Magic Link and hosting.
6. Do not deploy or configure Supabase until local release is accepted.

## Milestones

### M1: Local Stability, v0.7.x

Goal:
- Daily-use app without Supabase dependency.

Acceptance:
- Daniil / Second local accounts work.
- Calendar renders correctly.
- Workout focus mode saves sets.
- Recovery and nutrition save.
- Backup and restore work.
- Diagnostics export works.
- Mobile browser smoke test is done.

### M2: Workout Engine Pro, v0.8.x

Goal:
- Real training experience.

Scope:
- One exercise / one set at a time.
- Better rest timer.
- Set summary during workout.
- Skip / replace exercise.
- Workout completion summary.

### M3: Progress Intelligence, v0.9.x

Goal:
- Useful recommendations.

Scope:
- Next weight logic.
- Increase / repeat / reduce.
- Best set.
- Last session.
- Trends by exercise.
- Weekly review.

### M4: Ship Calendar Intelligence, v1.0.x

Goal:
- App adapts to port schedule.

Scope:
- Port-day logic.
- Missed workout recovery.
- Manual move.
- Recovery-only day.
- Weekly compliance.

### M5: Supabase Cloud, v1.1.x

Goal:
- Private cloud sync.

Scope:
- Separate Supabase project.
- Magic Link login.
- RLS-protected history.
- Pull / sync.

### M6: Hosted PWA, v1.2.x

Goal:
- Installed app on phone.

Scope:
- Cloudflare Pages.
- PWA install.
- Offline app shell.
- Final smoke test.

## Current status

Current build:
- v0.7.1 Real Local Audit & Cleanup

Status:
- PREPARED
- NOT DEPLOYED
- NOT MOBILE TESTED

## Next action

Next build after user says continue:
- v0.7.2 Real UI/Text Cleanup and Manual QA Support.
