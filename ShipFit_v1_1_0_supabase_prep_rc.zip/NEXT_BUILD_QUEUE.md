# ShipFit Next Build Queue

## Current

v1.0.0 Final Local Release is ready for test deploy.

## Next actions

1. Test deploy
   - Upload v1.0.0.
   - Complete DEPLOY_TEST_CHECKLIST.md.

2. v1.0.1 Bugfix, only if needed
   - Fix any issues found during test deploy or mobile smoke.

3. v1.1.0 Supabase Magic Link
   - Only after v1.0.0 or v1.0.1 is accepted.

4. v1.2.0 Hosted PWA hardening
   - Only after Supabase is accepted.
