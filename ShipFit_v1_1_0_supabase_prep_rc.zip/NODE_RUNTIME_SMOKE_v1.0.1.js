
const fs = require('fs');
const path = require('path');
const appCode = fs.readFileSync(path.join(__dirname, "js/app.js"), 'utf8');

const ids = ["toast", "confetti", "offlineStatus", "loginScreen", "supabaseUrl", "supabaseAnon", "loginEmail", "settingsLoginEmail", "loginStatus", "profileChip", "langToggle", "today", "todayDate", "shipStatus", "phase", "dayStatusBanner", "dsBadge", "dsTitle", "dsSub", "dsReason", "todayCTA", "btnStartWorkout", "quickActions", "btnTired", "btnMove", "btnSkip", "weekRing", "weekPct", "weekDone", "streakText", "currentWeight", "targetWeight", "nextPort", "backupMiniStatus", "weekStrip", "weekCompliance", "lastWorkoutSummary", "todayWorkoutSection", "exerciseCard", "exerciseCardTitle", "workoutMeta", "exerciseList", "recSleep", "recFatigue", "recSoreness", "recNote", "recoveryAdvice", "nutProtein", "nutWater", "nutCalories", "nutNote", "nutCreatine", "nutOmega", "nutMulti", "nutAshwa", "nutritionSummary", "calendar", "calendarIntelligenceSummary", "monthTitle", "monthHead", "monthCal", "portList", "workout", "workoutPreview", "library", "progress", "weightInput", "weightChart", "weightHistory", "strengthInput", "strengthHistory", "exerciseProgressDashboard", "nextWorkoutIntelligence", "weeklyProgressReview", "progressInsights", "backupStatus", "syncStatus", "nutritionWeeklySummary", "workoutSummaryHistory", "progressCompliance", "plan", "roadmapOverview", "currentMilestone", "releaseGate", "verificationStatusPanel", "manualQaPanel", "nextBuildQueue", "settings", "setStartWeight", "setTargetWeight", "setWeeklyTarget", "pwaStatus", "qaStatusPanel", "workoutModal", "modalTitle", "modalSub", "workoutProgressHero", "timerLabel", "timer", "focusWorkoutPanel", "workoutCompletionPanel", "modalExercises", "finishSummaryPreview", "dayModal", "dayModalTitle", "dayModalSub", "dayModalBanner", "dayModalContent", "dayModalActions", "dayModalExercises", "skipModal", "skipAdvice", "readinessModal", "readBar", "readinessContent"];
const navTabs = ["today", "calendar", "workout", "progress", "plan", "settings"];
const sections = ["today", "calendar", "workout", "progress", "plan", "settings"];

class ClassList {
  constructor(){ this.set = new Set(); }
  add(...xs){ xs.forEach(x=>this.set.add(x)); }
  remove(...xs){ xs.forEach(x=>this.set.delete(x)); }
  toggle(x, force){ if(force===undefined){ this.set.has(x)?this.set.delete(x):this.set.add(x); } else { force?this.set.add(x):this.set.delete(x); } }
  contains(x){ return this.set.has(x); }
}
class El {
  constructor(id=null){ this.id=id; this.value=''; this.checked=false; this.textContent=''; this._innerHTML=''; this.style={setProperty(k,v){this[k]=v;}, removeProperty(k){delete this[k];}}; this.dataset={}; this.classList=new ClassList(); this.children=[]; }
  set innerHTML(v){ this._innerHTML=String(v); }
  get innerHTML(){ return this._innerHTML; }
  appendChild(el){ this.children.push(el); return el; }
  remove(){}
  addEventListener(){}
  setAttribute(k,v){ this[k]=v; }
  getAttribute(k){ return this[k]||''; }
  querySelectorAll(sel){ return []; }
  querySelector(sel){ return null; }
}

const elements = new Map();
function getEl(id){ if(!elements.has(id)) elements.set(id,new El(id)); return elements.get(id); }
ids.forEach(getEl);
['toast','confetti','offlineStatus','focusWeight','focusReps','dayModalExList'].forEach(getEl);
sections.forEach(id=>getEl(id).classList.add('section'));
getEl('today').classList.add('active');

const navButtons = navTabs.map(t=>{ const e=new El(); e.dataset.tab=t; return e; });
const supabaseInputs = [getEl('supabaseUrl'), getEl('supabaseAnon')];

global.window = {
  localStorage: {
    data: new Map(),
    getItem(k){ return this.data.has(k)?this.data.get(k):null; },
    setItem(k,v){ this.data.set(k,String(v)); },
    removeItem(k){ this.data.delete(k); },
    key(i){ return [...this.data.keys()][i]||null; },
    get length(){ return this.data.size; }
  },
  addEventListener(){},
  matchMedia(){ return {matches:false}; },
  scrollTo(){},
  location: { protocol:'http:', origin:'http://localhost', pathname:'/index.html', href:'http://localhost/index.html' },
  supabase: null,
};
global.localStorage = global.window.localStorage;
global.location = global.window.location;
global.navigator = { onLine:true, userAgent:'node-smoke' };
global.caches = { keys: async()=>[], delete: async()=>true, open: async()=>({addAll:async()=>true, put:async()=>true}) };
global.URL = URL;
global.Blob = Blob;
global.confirm = () => true;
global.alert = () => {};
global.setTimeout = setTimeout;
global.setInterval = setInterval;
global.clearInterval = clearInterval;
global.requestAnimationFrame = (cb)=>setTimeout(cb,0);

global.document = {
  readyState:'complete',
  body: getEl('body'),
  createElement(tag){ return new El(); },
  addEventListener(ev, cb){ if(ev==='DOMContentLoaded') setTimeout(cb,0); },
  getElementById(id){ return getEl(id); },
  querySelector(sel){
    if(sel==='.app') return getEl('app');
    if(sel==='.nav') return getEl('nav');
    if(sel==='[data-supabase-url]' || sel==='#supabaseUrl') return getEl('supabaseUrl');
    if(sel==='[data-supabase-anon]' || sel==='#supabaseAnon') return getEl('supabaseAnon');
    return null;
  },
  querySelectorAll(sel){
    if(sel==='.section') return sections.map(getEl);
    if(sel==='.nav button') return navButtons;
    if(sel==='[data-supabase-url],#supabaseUrl') return [getEl('supabaseUrl')];
    if(sel==='[data-supabase-anon],#supabaseAnon') return [getEl('supabaseAnon')];
    if(sel==='[data-supabase-email],#settingsLoginEmail,#loginEmail') return [getEl('settingsLoginEmail'), getEl('loginEmail')];
    if(sel==='.setTick') return [];
    return [];
  }
};

const errors = [];
process.on('uncaughtException', (e)=>{ errors.push(e.stack||String(e)); });

try {
  eval(appCode);
  setTimeout(()=>{
    const checks = [];
    function check(name, ok, detail=''){ checks.push({name, status:ok?'PASS':'FAIL', detail}); }
    check('APP_VERSION', window.SHIPFIT_VERSION === '1.1.0-supabase-prep', window.SHIPFIT_VERSION || 'missing');
    check('renderAll available', typeof renderAll === 'function');
    check('showSection available', typeof showSection === 'function');
    check('renderProgressIntelligence available', typeof renderProgressIntelligence === 'function');
    check('renderVerificationStatus available', typeof renderVerificationStatus === 'function');
    try { showSection('progress'); check('showSection progress call', true); } catch(e) { check('showSection progress call', false, e.message); }
    try { showSection('plan'); check('showSection plan call', true); } catch(e) { check('showSection plan call', false, e.message); }
    try { renderAll(); check('renderAll call', true); } catch(e) { check('renderAll call', false, e.message); }
    try { loginLocalProfile('daniil','Daniil'); check('Daniil default language', getLang() === 'ru', getLang()); } catch(e) { check('Daniil default language', false, e.message); }
    try { loginLocalProfile('second','Second account'); check('Second default language', getLang() === 'en', getLang()); } catch(e) { check('Second default language', false, e.message); }
    try { window.localStorage.setItem('shipfit:second:shipfitLang','ru'); loginLocalProfile('daniil','Daniil'); check('Daniil language isolated after Second override', getLang() === 'ru', getLang()); } catch(e) { check('Daniil language isolated after Second override', false, e.message); }
    try { check('cloudProfileId keeps local profile', cloudProfileId() === 'daniil', cloudProfileId()); } catch(e) { check('cloudProfileId keeps local profile', false, e.message); }
    try { renderCloudStatus(); check('renderCloudStatus call', true); } catch(e) { check('renderCloudStatus call', false, e.message); }
    console.log(JSON.stringify({checks, errors}, null, 2));
    process.exit(errors.length ? 1 : (checks.every(c=>c.status==='PASS') ? 0 : 2));
  }, 300);
} catch(e) {
  console.log(JSON.stringify({checks:[], errors:[e.stack||String(e)]}, null, 2));
  process.exit(1);
}
