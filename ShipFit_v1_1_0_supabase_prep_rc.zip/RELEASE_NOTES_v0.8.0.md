# Release Notes: ShipFit v0.8.0 Workout Engine Pro

## Summary

This release upgrades the workout experience. It is still a local-only prepared build, not deployed and not browser-smoke-tested.

## Changed files

- index.html
- css/styles.css
- js/app.js
- README.txt
- QA_LOCAL_RC.md
- CURRENT_RELEASE_STATUS.md
- NEXT_BUILD_QUEUE.md
- RELEASE_NOTES_v0.8.0.md
- STATIC_AUDIT_v0.8.0.md

## What changed

- Focus Mode became the primary workout flow.
- Added workout progress hero.
- Added per-exercise progress bar.
- Added better set controls with plus/minus buttons.
- Rest timer now persists during the active workout.
- Added rest stop button.
- Added all-done workout completion state.
- Improved workout summaries with volume and skipped count.
- All exercises table is now secondary/collapsible.

## Verification

- JS syntax: PASS.
- Duplicate HTML IDs: PASS.
- Inline handler target functions: PASS.
- Duplicate JS function declarations: PASS.
- Browser click-through: NOT TESTED.
- Mobile smoke test: NOT TESTED.

## Known limitations

- This is not a medical training plan.
- Real gym usability still needs manual testing.
- Supabase and hosting remain deferred.
- PWA install requires http/https.
- Remote GIFs still need internet.

## Rollback

Use v0.7.2 UI/Text Cleanup + Manual QA Support if the new workout modal causes any issue.

## Next recommended step

v0.9.0 Progress Intelligence, unless manual QA finds P0/P1 bugs.
