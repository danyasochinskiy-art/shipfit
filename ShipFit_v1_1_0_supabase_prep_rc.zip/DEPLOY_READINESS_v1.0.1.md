# ShipFit v1.0.1 Deploy Readiness

Status: PREPARED FOR FREE STATIC HOST TEST DEPLOY.

## Verified before deploy

- Static HTML/CSS/JS app structure present.
- `node --check js/app.js`: PASS.
- `node NODE_RUNTIME_SMOKE_v1.0.1.js`: PASS.
- Bilingual user defaults:
  - Daniil: RU by default.
  - Second: EN by default.
  - Per-profile language isolation: PASS.
- Supabase remains deferred to v1.1.0.
- No external JS dependencies added.

## Pre-deploy patch included

- `sw.js` cache name updated from `shipfit-v0-6-1-shell` to `shipfit-v1-0-1-shell`.

## Still not verified

- Real browser smoke test: NOT TESTED.
- Real mobile/PWA install test: NOT TESTED.
- Offline behavior after Cloudflare Pages deploy: NOT TESTED.

## Recommended deploy target

Cloudflare Pages, Netlify, Vercel, GitHub Pages, or any HTTPS static hosting.

For PWA/service worker testing, HTTPS is required. Localhost is acceptable only for local development.
