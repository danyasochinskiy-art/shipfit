# ShipFit v1.0.1 RC Deploy Test Checklist

## Upload

- [ ] Upload the contents of this folder or the ZIP to test hosting.
- [ ] Open the HTTPS URL.
- [ ] Do not configure Supabase yet.

## First load

- [ ] Page opens without blank screen.
- [ ] Login screen is visible.
- [ ] Click Daniil local.
- [ ] Top profile chip shows Daniil.
- [ ] Bottom nav is visible and not clipped.

## Today tab

- [ ] Verification Hardened RC card is visible.
- [ ] Recovery card appears on Today tab.
- [ ] Nutrition tracker appears on Today tab.
- [ ] Recovery/Nutrition are NOT visible on Calendar/Progress/Plan/Settings.

## Workout

- [ ] Start workout.
- [ ] Readiness modal opens.
- [ ] Workout modal opens.
- [ ] Focus panel shows one exercise and one set.
- [ ] Save one set.
- [ ] Rest timer starts.
- [ ] Stop rest works.
- [ ] Skip exercise works.
- [ ] Finish workout creates summary.

## Progress

- [ ] Progress tab opens.
- [ ] Exercise Progress dashboard is visible.
- [ ] Next workout intelligence is visible.
- [ ] Weekly progress review is visible.
- [ ] Progress insights is visible.

## Backup

- [ ] Export backup downloads JSON.
- [ ] Export diagnostics downloads JSON.
- [ ] Import backup works after reload.

## PWA

- [ ] Enable offline shell on HTTPS.
- [ ] Browser does not show service worker error.
- [ ] Offline status appears when browser is offline.
- [ ] App shell reloads offline.

## Manual QA

- [ ] Open Plan tab.
- [ ] Start QA session.
- [ ] Mark at least one item PASS.
- [ ] Add a note.
- [ ] Export QA report.

## Result

- [ ] PASS
- [ ] FAIL
- [ ] BLOCKED
