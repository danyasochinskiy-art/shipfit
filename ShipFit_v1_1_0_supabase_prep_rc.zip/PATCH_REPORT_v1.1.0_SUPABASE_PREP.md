# ShipFit v1.1.0 Supabase Prep Patch Report

## Status

PREPARED, STATIC VERIFIED, NODE SMOKE VERIFIED, BROWSER/MOBILE/SUPABASE LIVE TEST NOT TESTED.

## Changed files

- `index.html`
- `js/app.js`
- `sw.js`
- `supabase_schema.sql`
- `NODE_RUNTIME_SMOKE_v1.1.0.js`
- `NODE_RUNTIME_SMOKE_v1.1.0_output.json`
- `SUPABASE_SETUP_v1.1.0.md`
- `PATCH_REPORT_v1.1.0_SUPABASE_PREP.md`
- `FILE_MANIFEST_SHA256.txt`

## Main changes

- App version changed to `1.1.0-supabase-prep`.
- Supabase is now prepared as optional profile backup/sync.
- Added Supabase client script to `index.html`.
- Added Supabase email field and Magic Link button in Settings.
- Supabase Auth session no longer replaces local profile ID with Auth UUID.
- Cloud sync now keeps the two local profile IDs: `daniil` and `second`.
- Added device ID and app version to cloud sync row.
- Pull from Supabase warns before replacing local profile data.
- Cloud status panel now shows config/session/sync state.
- PWA cache name updated to `shipfit-v1-1-0-supabase-prep-shell`.
- SQL schema hardened with RLS, profile check constraint, grants and verification queries.

## Verification

- `node --check js/app.js`: PASS
- `node NODE_RUNTIME_SMOKE_v1.1.0.js`: PASS
- Duplicate function declarations: PASS
- Duplicate HTML IDs: PASS
- Boot order: PASS
- Recovery/Nutrition Today boundary: PASS
- Real browser smoke: NOT TESTED
- Real Supabase Magic Link: NOT TESTED

## Known limitations

- Supabase CDN must load for Magic Link and cloud sync.
- Supabase project, Auth settings and redirect URLs must be configured manually.
- Cloud sync is JSON backup based, not row-level workout/event sync.
- Conflict resolution is manual: Pull replaces current local profile after confirmation.
- No Storage bucket is used in this version.
