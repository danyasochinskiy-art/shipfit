# Release Notes: ShipFit v0.7.0 Global Product Foundation

## Summary

This release does not deploy Supabase or hosting. It creates a more controlled product-development foundation.

## Added

- New in-app Plan tab.
- Global roadmap inside the app.
- Current milestone block.
- Release gate checklist with editable statuses.
- Next build queue.
- Project documentation files.

## Why

The project was moving too incrementally. This version establishes a clear milestone structure so future "continue" commands follow a consistent global plan.

## Verification

- node --check js/app.js: PASS
- Manifest JSON: inherited from v0.6.1
- Browser/mobile smoke test: NOT TESTED

## Rollback

Use v0.6.1 PWA QA Polish ZIP if the new Plan tab creates any issue.

## Next

v0.7.1 UI consistency and text cleanup.
