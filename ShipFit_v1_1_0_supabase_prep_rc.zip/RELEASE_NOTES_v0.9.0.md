# Release Notes: ShipFit v0.9.0 Progress Intelligence + Critical Bugfix

## Summary

This release fixes critical v0.8.0 layout/logic bugs and adds the next milestone: Progress Intelligence.

## Critical bugfixes

1. Recovery + Nutrition cards were outside `<section id="today">`.
   - Fixed by moving the Today closing section boundary after Nutrition tracker.

2. `localHealthChecks()` was hardcoded to `APP_VERSION === "0.7.1"`.
   - Fixed to validate the v0.9.x version family.

3. `setupLanguage()` was never called during boot.
   - Fixed by calling `setupLanguage()` in `bootShipFitV090()`.

## Added

- Next workout intelligence.
- Weekly progress review.
- Progress insights.
- Set volume analysis.
- Training days consistency.
- Volume delta versus previous 7 days.
- Recommendation cards for next exercises.

## Verification

- node --check js/app.js: PASS
- duplicate HTML IDs: PASS
- inline handler target functions: PASS
- duplicate function declarations: PASS
- Today section boundary: PASS
- Browser/mobile smoke test: NOT TESTED

## Known limitations

- Data is only useful after at least one workout is logged through Focus Mode.
- Progress logic is still conservative and local-only.
- Supabase and hosting remain deferred.

## Rollback

Use v0.8.0 only if v0.9.0 creates a new blocking issue, but v0.8.0 has known critical bugs.

## Next recommended step

v1.0.0 Local Release Candidate, unless v0.9.1 bugfix is needed after manual test.
