# Release Notes: ShipFit v0.7.1 Real Local Audit & Cleanup

## Summary

This release fixes structural issues introduced by quick milestone patches and makes the app safer for local QA.

## Fixes

- Missing `showSection()` restored.
- Initial boot moved after all declarations.
- `buildWorkoutSummaryDraft()` added.
- Duplicate function declarations cleaned.
- Login screen aligned with Magic Link/local mode.
- `loginStatus` DOM element added.
- QA version check updated.

## Verification performed

- `node --check js/app.js`: PASS.
- Static audit for duplicate IDs: PASS.
- Static audit for inline handler function names: PASS.
- Static audit for static DOM ID references: PASS, except dynamic IDs created by JS.

## Not verified

- Real browser click-through.
- Mobile Safari.
- Supabase Magic Link.
- Cloudflare/PWA installed mode.

## Rollback

Use v0.7.0 only as a documentation snapshot. For actual app testing, prefer v0.7.1.
