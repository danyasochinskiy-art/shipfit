# Release Notes: ShipFit v0.7.2 UI/Text Cleanup + Manual QA Support

## Summary

This build continues the local-first stabilization phase. It does not deploy Supabase or hosting.

## Changed files

- index.html
- css/styles.css
- js/app.js
- README.txt
- QA_LOCAL_RC.md
- CURRENT_RELEASE_STATUS.md
- NEXT_BUILD_QUEUE.md
- RELEASE_NOTES_v0.7.2.md
- STATIC_AUDIT_v0.7.2.md

## What changed

- Added Manual QA Session panel in Plan tab.
- Added PASS / FAIL / BLOCKED / NOT TESTED selector per QA item.
- Added free-text QA notes.
- Added QA report export JSON.
- Cleaned several visible mixed-language labels.
- Changed bottom navigation to support 6 tabs cleanly.
- Updated Supabase wording to show it is deferred.

## Verification

- JS syntax: PASS.
- Duplicate HTML IDs: PASS.
- Inline handler target functions: PASS.
- Duplicate JS function declarations: PASS.
- Browser click-through: NOT TESTED.
- Mobile smoke test: NOT TESTED.

## Known limitations

- Some older Russian/English mixed labels remain in deeper workout content.
- GIFs remain remote.
- PWA still requires http/https.
- Supabase Magic Link remains prepared but not configured.

## Rollback

Use v0.7.1 Real Local Audit & Cleanup if Plan tab QA panel causes any issue.

## Next recommended step

v0.8.0 Workout Engine Pro, unless manual QA reveals P0 bugs first.
