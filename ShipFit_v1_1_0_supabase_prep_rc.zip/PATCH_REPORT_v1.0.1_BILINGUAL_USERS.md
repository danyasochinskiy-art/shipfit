# ShipFit v1.0.1 Bilingual Users Patch

Status: PREPARED, STATIC VERIFIED, NODE SMOKE VERIFIED, BROWSER/MOBILE NOT TESTED.

## Goal

Make ShipFit behave as a bilingual local app for two isolated users:

- Daniil: default language `ru`.
- Second account: default language `en`.

The language setting remains profile-scoped through `LS.get()` / `LS.set()` and is not stored as a global key.

## Changed files

- `js/app.js`
- `NODE_RUNTIME_SMOKE_v1.0.1.js`
- `FILE_MANIFEST_SHA256.txt`
- `PATCH_REPORT_v1.0.1_BILINGUAL_USERS.md`

## Exact changes

### `js/app.js`

- Added `PROFILE_DEFAULTS` with profile names and default language.
- Changed `currentProfileName()` to use profile defaults.
- Added profile language helpers:
  - `defaultLangForProfile()`
  - `profileLangKey()`
  - `ensureProfileLanguage()`
- Changed `getLang()` so default language is taken from the active profile.
- Kept `shipfitLang` profile-scoped through `LS`, not global localStorage.
- Added `I18N_REVERSE` so static English HTML can be translated back to Russian for Daniil.
- Changed `translateNode()` to support both directions:
  - RU source to EN for Second account.
  - EN source to RU for Daniil.
- Changed `setupLanguage()` so localization observer works for both languages, not only English.
- Updated `loginLocalProfile()` so profile language is initialized before render.
- Updated `logoutProfile()` so login screen returns to Daniil/RU default.
- Improved visible-scope handling in `saveSupabaseConfig()` for future v1.1.0 work without activating Supabase.
- Localized PWA status labels and nutrition weekly mini-metrics.

### `NODE_RUNTIME_SMOKE_v1.0.1.js`

- Replaced hardcoded absolute `/mnt/data/.../js/app.js` path with portable `path.join(__dirname, "js/app.js")`.
- Added bilingual profile checks:
  - Daniil default language = `ru`.
  - Second account default language = `en`.
  - Second account language override does not affect Daniil.

## Verification performed

```bash
node --check js/app.js
node NODE_RUNTIME_SMOKE_v1.0.1.js
```

Result: PASS.

Additional static checks:

- Duplicate HTML IDs: PASS.
- Duplicate function declarations: PASS.
- Boot order: PASS.
- Recovery section stays inside `<section id="today">`: PASS.
- Nutrition section stays inside `<section id="today">`: PASS.

## Known limitations

- Real browser smoke test: NOT TESTED.
- Mobile smoke test: NOT TESTED.
- Some technical QA/status labels still intentionally use English terms such as PASS, FAIL, BLOCKED and NOT TESTED.
- Supabase remains deferred to v1.1.0.

## Manual browser checks required

1. Open fresh app.
2. Login as Daniil.
3. Confirm UI is Russian and language button shows `EN`.
4. Toggle to English, reload, confirm Daniil stays English only if changed manually.
5. Logout.
6. Login as Second account.
7. Confirm UI is English by default and language button shows `RU`.
8. Toggle Second to Russian.
9. Logout and login as Daniil.
10. Confirm Daniil language remains independent from Second.

## Rollback

Restore original files from `ShipFit_v1_0_1_verification_hardening_rc.zip`:

- `js/app.js`
- `NODE_RUNTIME_SMOKE_v1.0.1.js`
- `FILE_MANIFEST_SHA256.txt`

